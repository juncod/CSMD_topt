function saveFunction_BCmap(saveBCName, BC_map)
%     saveMatName = strcat(saveBCName,'.mat');
    saveXlsName = strcat(saveBCName,'.xlsx');
    xlswrite(saveXlsName,BC_map)
%     save(saveMatName,'BC_map','-v7.3','-nocompression')
end